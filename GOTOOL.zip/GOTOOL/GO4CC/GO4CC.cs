
namespace GO4CC
{
    public class GO4CC
    {

    }
}
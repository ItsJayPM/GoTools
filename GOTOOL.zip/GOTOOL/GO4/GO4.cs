
namespace GO4
{
    public class GO4
    {

    }
}
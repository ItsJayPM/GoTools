
namespace GoAnimateRipper
{
    public class GoAnimateRipper
    {

    }
}